import torch
import torch.nn as nn
import numpy as np
from model import BRDF_directmodel
from BRDFdata import BRDFdata
import argparse, math, os, shutil, sys, time, datetime
import matplotlib.pyplot as plt

def str2bool(v):
	if v.lower() in ('yes', 'true', 't', 'y', '1'):
		return True
	elif v.lower() in ('no', 'false', 'f', 'n', '0'):
		return False
	else:
		raise argparse.ArgumentTypeError('Boolean value expected.')


parser = argparse.ArgumentParser()
parser.add_argument('--train_path', default='../data/filter_train_spectral_magenta.xlsx')
parser.add_argument('--test_path', default='../data/filter_test_spectral_magenta.xlsx')
parser.add_argument('--checkpoint_path',default='../experiments/magenta_spectral/')
parser.add_argument('--checkpoint_name',default='checkpoint_22_best.pth.tar')
parser.add_argument('--batchsize', default=360)
parser.add_argument('--epochs', default=30)
parser.add_argument('--scale', default=3)
parser.add_argument('--sink', type=str2bool, default=False)
parser.add_argument('--reset', type=str2bool, default=True)
args = parser.parse_args()

# Different combinations of command-line arguments -
# sink	reset	-->	action 
# T		T		-->	Accuracy testing without any training
# T		F		-->	only Testing
# F		T		-->	Training from starting
# F		F		-->	Resume Training from a checkpoint

# Making the code Reproducible
seedVal = 0
np.random.seed(seedVal)
torch.manual_seed(seedVal)
torch.cuda.manual_seed(seedVal)

# Change the flags to control what happens.
doLoad = not args.reset # Load checkpoint at the beginning
doTest = args.sink # Only run test, no training

epochs = int(args.epochs)
batch_size =  int(args.batchsize)

base_lr = 0.01
momentum = 0.9
weight_decay = 1e-4
lr = base_lr
prec1 = np.inf
best_prec1 = np.inf

GPU_device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
fr_max = 1
fr_min = 0

def load_checkpoint(filename=''):
	filename = os.path.join(args.checkpoint_path,args.checkpoint_name)
	state = torch.load(filename, map_location=GPU_device)
	return state

def save_checkpoint(state, is_best, filename):
	directory = args.checkpoint_path
	filename = os.path.join(directory,filename)

	if not os.path.exists(directory):
		os.makedirs(directory)

	bestFilename = filename.replace('.pth.tar', '_best.pth.tar')
	torch.save(state, filename)
	if is_best:
		shutil.copyfile(filename, bestFilename)


def adjust_learning_rate(epoch):
	"""Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""
	lr = base_lr * (0.1 ** (epoch // 15))
	return lr


class CustomLoss(nn.Module):
	def __init__(self,scale=3.0):
		super(CustomLoss,self).__init__()
		self.scale = float(scale)

	def forward(self, output, target, directions):
		incident = math.pi * directions[:, [0]] / 180
		viewing = math.pi * directions[:, [1]] / 180
		diff_angles = torch.abs(incident-viewing)
		scale = torch.exp(-self.scale*diff_angles)
		diff = (output - target)* scale
		loss = torch.sqrt(torch.sum(torch.pow(diff, 2)) / len(output))
		return loss


def main():
	global args, momentum, weight_decay, best_prec1, fr_max, fr_min

	model = BRDF_directmodel()
	model.to(device=GPU_device)

	epoch = 1

	if doLoad:
		saved = load_checkpoint()
		if saved:
			state = saved['state_dict']
			try:
				model.module.load_state_dict(state)
			except:
				model.load_state_dict(state)
			epoch = saved['epoch'] + 1
			best_prec1 = saved['best_prec1']

		else:
			print('Warning: Could not read checkpoint!')
			sys.exit(1)

	metadata = {}		
	dataTrain = BRDFdata(dataPath=args.train_path, metadata=metadata,split='train')
	print(metadata)
	dataVal = BRDFdata(dataPath=args.test_path, metadata=metadata,split='val')
	fr_max = metadata['fr_max']
	fr_min = metadata['fr_min']

	train_loader = torch.utils.data.DataLoader(
		dataTrain,
		batch_size=batch_size, shuffle=True, pin_memory=True)

	val_loader = torch.utils.data.DataLoader(
		dataVal,
		batch_size=batch_size, shuffle=False, pin_memory=True)

	criterion = CustomLoss(scale=args.scale)
	
	metric = torch.nn.MSELoss()

	optimizer = torch.optim.Adam(model.parameters(), lr=base_lr)

    # # Quick test
	if doTest:
		validate(val_loader, model, criterion, metric, epoch-1)
		return

	train_loss = []
	val_mse = []

    #### Training Code for Classification #####
	for epoch in range(epoch, epochs+1):
		lr = adjust_learning_rate(epoch-1)
		for param_group in optimizer.state_dict()['param_groups']:
			param_group['lr'] = lr

		# train for one epoch
		cur_train_loss = train(train_loader, model, criterion, metric, optimizer, epoch)
		train_loss.append(cur_train_loss)

		print("Training DONE. Not saving checkpoint for this ...")

		# evaluate on validation set
		prec1 = validate(val_loader, model, criterion, metric, epoch)
		val_mse.append(prec1)
		print("Validation DONE. Overwriting checkpoint with validations's best_prec1 ...")

		# remember best prec@1 and save checkpoint
		is_best = prec1 < best_prec1
		best_prec1 = min(prec1, best_prec1)
		if (is_best or epoch == epochs):
			save_checkpoint({
				'epoch': epoch,
				'state_dict': model.state_dict(),
				'best_prec1': best_prec1,
				'train_losses': train_loss,
				'val_mses': val_mse
			}, is_best, 'checkpoint_%d.pth.tar' % (epoch))
			print('Checkpoint overwritten successfully.')

		if (epoch+1) % 5 == 0:
			plt.plot(val_mse)
			plt.title('Validation Error vs Epochs')
			plt.xlabel('Epoch')
			plt.ylabel('MSE')
			plt.savefig(os.path.join(args.checkpoint_path,"validation_plot.png"))

	###########################################


def train(train_loader, model, criterion, metric, optimizer, epoch):
	batch_time = AverageMeter()
	data_time = AverageMeter()
	losses = AverageMeter()

	# switch to train mode
	model.train()

	end = time.time()

	for i, (brdf_input, brdf_input_scaled, brdf_gt) in enumerate(train_loader):

		# measure data loading time
		data_time.update(time.time() - end)
		brdf_input = brdf_input.to(device=GPU_device, non_blocking=True)
		brdf_input_scaled = brdf_input_scaled.to(device=GPU_device, non_blocking=True)
		brdf_gt = brdf_gt.to(device=GPU_device, non_blocking=True)
		
		brdf_input.requires_grad_(False)
		brdf_input_scaled.requires_grad_(False)
		brdf_gt.requires_grad_(False)

		# compute output
		output = model(brdf_input_scaled)

		loss = criterion(output, brdf_gt, brdf_input)

		unscaled_loss = metric((fr_max-fr_min)*output+fr_min,(fr_max-fr_min)*brdf_gt+fr_min)
		losses.update(unscaled_loss.data.item(), brdf_input.size(0))

		# compute gradient and do SGD step
		optimizer.zero_grad()
		loss.backward()

		optimizer.step()

		# measure elapsed time
		batch_time.update(time.time() - end)
		end = time.time()

		print('Epoch (train): [{0}][{1}/{2}]\t'
				  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
				  'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
				  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'.format(
				   epoch, i+1, len(train_loader), batch_time=batch_time,
				   data_time=data_time, loss=losses))

	return loss.detach().cpu().numpy().mean()

def validate(val_loader, model, criterion, metric, epoch):
	batch_time = AverageMeter()
	data_time = AverageMeter()
	losses = AverageMeter()

	# switch to evaluate mode
	model.eval()
	end = time.time()

	for i, (brdf_input, brdf_input_scaled, brdf_gt) in enumerate(val_loader):

		# measure data loading time
		data_time.update(time.time() - end)
		brdf_input = brdf_input.to(device=GPU_device, non_blocking=True)
		brdf_input_scaled = brdf_input_scaled.to(device=GPU_device, non_blocking=True)
		brdf_gt = brdf_gt.to(device=GPU_device, non_blocking=True)
		
		brdf_input.requires_grad_(True)
		brdf_input_scaled.requires_grad_(True)
		brdf_gt.requires_grad_(True)

		# compute output
		with torch.no_grad():
			output = model(brdf_input_scaled)
			loss = criterion(output, brdf_gt, brdf_input)

		unscaled_loss = metric((fr_max-fr_min)*output+fr_min,(fr_max-fr_min)*brdf_gt+fr_min)
		losses.update(unscaled_loss.data.item(), brdf_input.size(0))

		# measure elapsed time
		batch_time.update(time.time() - end)
		end = time.time()

		print('Epoch (val): [{0}][{1}/{2}]\t'
					'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
					'Loss {loss.val:.4f} ({loss.avg:.4f})\t'.format(
					epoch, i+1, len(val_loader), batch_time=batch_time,
					loss=losses))

	return loss.detach().cpu().numpy().mean()



class AverageMeter(object):
	"""Computes and stores the average and current value"""
	def __init__(self):
		self.reset()

	def reset(self):
		self.val = 0
		self.avg = 0
		self.sum = 0
		self.count = 0

	def update(self, val, n=1):
		self.val = val
		self.sum += val * n
		self.count += n
		self.avg = self.sum / self.count


if __name__ == "__main__":
	tic = time.time()
	main()
	toc = time.time()
	print('Total processing time = %s' % datetime.timedelta(seconds = toc-tic))
	print('DONE')    