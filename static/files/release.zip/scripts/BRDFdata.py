import torch.utils.data as data
import pandas as pd
import torch
import numpy as np

def getMean(sample_train, metaDict):
    means = sample_train.mean()
    std = sample_train.std()
    fr_max = max(sample_train.fr)
    fr_min = min(sample_train.fr)
    metaDict['wavelength_mean'] = means.wavelength
    metaDict['wavelength_std'] = std.wavelength
    metaDict['incident_mean'] = means.incident
    metaDict['incident_std'] = std.incident
    metaDict['viewing_mean'] = means.viewing
    metaDict['viewing_std'] = std.viewing
    metaDict['fr_max'] = fr_max
    metaDict['fr_min'] = fr_min

    return metaDict


class BRDFdata(data.Dataset):
    def __init__(self, dataPath, metadata, split='train'):
        self.df = pd.read_excel(dataPath)
        if split=='train':
            metadata = getMean(self.df,metadata)

        self.df['incident_scaled'] = self.df.incident.apply(lambda x: (x-metadata['incident_mean'])/metadata['incident_std'])
        self.df['viewing_scaled'] = self.df.viewing.apply(lambda x: (x-metadata['viewing_mean'])/metadata['viewing_std'])
        self.df['wavelength_scaled'] = self.df.wavelength.apply(lambda x: (x-metadata['wavelength_mean'])/metadata['wavelength_std'])
        self.df['fr'] = self.df.fr.apply(lambda x: (x-metadata['fr_min'])/(metadata['fr_max']-metadata['fr_min']))

    def __getitem__(self, index):
        input_data1 = self.df.iloc[index,:3]
        input_data2 = self.df.iloc[index,-3:]
        input_data1 = torch.FloatTensor(np.array(input_data1))
        input_data2 = torch.FloatTensor(np.array(input_data2))

        ground_truth = np.array(self.df.iloc[index,-4])
        ground_truth = torch.FloatTensor(ground_truth)

        return input_data1, input_data2, ground_truth

    def __len__(self):
        return len(self.df)