import torch

class BRDF_directmodel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.linear1 = torch.nn.Linear(3,10)
        self.linear2 = torch.nn.Linear(10,10)
        self.linear3 = torch.nn.Linear(10,1)
        self.relu1 = torch.nn.ReLU()
        self.relu2 = torch.nn.ReLU()
        self.relu3 = torch.nn.ReLU()
        self.mish1 = torch.nn.Mish()
        self.mish2 = torch.nn.Mish()
        self.dropout1 = torch.nn.Dropout(0.2)
        self.dropout2 = torch.nn.Dropout(0.2)

    def forward(self, x):
        x = self.mish1(self.linear1(x))
        x = self.dropout1(x)
        x = self.mish2(self.linear2(x))
        x = self.dropout2(x)
        x = self.relu3(self.linear3(x))

        return x.view(-1)