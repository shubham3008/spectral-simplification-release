"""
Copyright (c) 2025, Shubham Chitnis, Aditya Sole and Sharat Chandran
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""

import torch.utils.data as data
import pandas as pd
import torch
import numpy as np

def getMean(sample_train, metaDict):
    means = sample_train.mean()
    std = sample_train.std()
    fr_max = max(sample_train.fr)
    fr_min = min(sample_train.fr)
    metaDict['wavelength_mean'] = means.wavelength
    metaDict['wavelength_std'] = std.wavelength
    metaDict['incident_mean'] = means.incident
    metaDict['incident_std'] = std.incident
    metaDict['viewing_mean'] = means.viewing
    metaDict['viewing_std'] = std.viewing
    metaDict['fr_max'] = fr_max
    metaDict['fr_min'] = fr_min

    return metaDict


class BRDFdata(data.Dataset):
    def __init__(self, dataPath, metadata, split='train'):
        self.df = pd.read_excel(dataPath)
        if split=='train':
            metadata = getMean(self.df,metadata)

        self.df['incident_scaled'] = self.df.incident.apply(lambda x: (x-metadata['incident_mean'])/metadata['incident_std'])
        self.df['viewing_scaled'] = self.df.viewing.apply(lambda x: (x-metadata['viewing_mean'])/metadata['viewing_std'])
        self.df['wavelength_scaled'] = self.df.wavelength.apply(lambda x: (x-metadata['wavelength_mean'])/metadata['wavelength_std'])
        self.df['fr'] = self.df.fr.apply(lambda x: (x-metadata['fr_min'])/(metadata['fr_max']-metadata['fr_min']))

    def __getitem__(self, index):
        input_data1 = self.df.iloc[index,:3]
        input_data2 = self.df.iloc[index,-3:]
        input_data1 = torch.FloatTensor(np.array(input_data1))
        input_data2 = torch.FloatTensor(np.array(input_data2))

        ground_truth = np.array(self.df.iloc[index,-4])
        ground_truth = torch.FloatTensor(ground_truth)

        return input_data1, input_data2, ground_truth

    def __len__(self):
        return len(self.df)